const TaskAssignmentProMax = artifacts.require("TaskAssignmentProMax");

module.exports = function(deployer) {
    deployer.deploy(TaskAssignmentProMax);
};