const TaskAssignmentDouble = artifacts.require("TaskAssignmentDouble");

module.exports = function(deployer) {
    deployer.deploy(TaskAssignmentDouble);
};